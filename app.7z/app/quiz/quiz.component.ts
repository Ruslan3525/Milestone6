import { Component, OnInit } from '@angular/core';
import { Quiz } from '../quiz.model';
import {QuizService} from '../quiz.service';
@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
quizzes: Quiz[] = [];
showButton: boolean;
answerSelected = false;
correctAnswers = 0;
incorrectAnswers = 0;
indexOfAnswer = -1;
currentQuiz = 0;
randomize: number;
quizzy: any [10];
num = 0;
x: number;


result = false;


  constructor(private quizService: QuizService) {
   }

  ngOnInit(): void {
    this.quizzes = this.quizService.getQuizzes();
    this.randomize = Math.floor(Math.random() * this.quizzes.length);
    this.quizzy = [this.currentQuiz];
  }

  onAnswer(index: number) {
   this.indexOfAnswer = index;
}

  checkAnswer(): void{
    this.arrlist();
    let option = false;
    if(this.indexOfAnswer > -1){
      option = this.quizzes[this.num].answer[this.indexOfAnswer].correct;
      if(option){
       this.correctAnswers++;
      } else
      {
        this.incorrectAnswers++;
      }
    }
    else {
      alert('Option is not chosen');
      return;
    }


  this.nextQuestion();

  }
  arrlist(){
    this.randomize = Math.floor(Math.random() * this.quizzes.length);
    this.quizzy[this.currentQuiz] = this.randomize;
    this.x = this.quizzy[this.currentQuiz];
  }
  nextQuestion(){
    this.arrlist();
    this.num++;
    this.currentQuiz++;
    this.answerSelected = false;
    this.indexOfAnswer = -1;

  }
  prevQuestion(){
  this.arrlist();
  this.currentQuiz--;
  this.num--;
  }
showResult(){
  this.result = true;
}
}
