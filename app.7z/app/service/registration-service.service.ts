import {Injectable} from '@angular/core';
import {User} from 'src/app/user';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegistrationServiceService {

  constructor(private http: HttpClient) {
  }

  public loginUserFromRemote(user: User): Observable<User[]> {
    // @ts-ignore
    return this.http.post('http://localhost:8080/login', user);
  }
}
