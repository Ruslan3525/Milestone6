import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  email: string;
  password: string;

  USER_NAME_SESSION_ATTRIBUTE_NAME = 'authenticatedUser';

  // tslint:disable-next-line:typedef
  registerSuccessfulLogin(email, password) {
    localStorage.setItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME, email);
  }

  constructor() {
  }

  // tslint:disable-next-line:typedef
  logout() {
    localStorage.removeItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME);
    this.email = null;
    this.password = null;
  }

  // tslint:disable-next-line:typedef
  isUserLoggedIn(): boolean {
    const user = localStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME);
    if (user === null) {
      return false;
    }
    return true;
  }
}
